package com.studentassistant.domain

import kotlinx.coroutines.flow.MutableStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/** نص الدرس/الملف الحالي، تقرأه شاشة المحادثة لتتذكر السياق */
@Singleton
class LessonContext @Inject constructor() {
    val text = MutableStateFlow("")
}
