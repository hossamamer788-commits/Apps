package com.studentassistant.domain

import com.studentassistant.data.remote.AiApi
import com.studentassistant.data.remote.ChatMessageDto
import com.studentassistant.data.remote.ChatRequest
import com.studentassistant.data.remote.OpenAiRequest
import com.studentassistant.data.settings.SettingsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import javax.inject.Inject
import javax.inject.Singleton

class MissingKeyException : Exception("no key")

@Singleton
class AiRepository @Inject constructor(
    private val api: AiApi, private val json: Json, private val settings: SettingsStore,
) {
    fun stream(req: ChatRequest): Flow<String> = flow {
        val p = settings.provider
        val key = settings.key(p)
        if (key.isBlank()) throw MissingKeyException()
        val msgs = listOf(ChatMessageDto("system", req.system)) + req.messages
        api.stream(p.url, "Bearer $key", OpenAiRequest(settings.model(p), msgs)).use { body ->
            val src = body.source()
            while (!src.exhausted()) {
                val line = src.readUtf8Line() ?: break
                if (!line.startsWith("data:")) continue
                val data = line.removePrefix("data:").trim()
                if (data == "[DONE]") break
                val delta = runCatching {
                    ((json.parseToJsonElement(data).jsonObject["choices"] as JsonArray)[0] as JsonObject)["delta"]
                        ?.jsonObject?.get("content")?.jsonPrimitive?.contentOrNull
                }.getOrNull()
                if (!delta.isNullOrEmpty()) emit(delta)
            }
        }
    }.flowOn(Dispatchers.IO)

    suspend fun complete(req: ChatRequest): String {
        val sb = StringBuilder()
        stream(req).collect { sb.append(it) }
        return sb.toString()
    }
}
