package com.studentassistant.domain

enum class Level(val label: String) { SHORT("قصير"), MEDIUM("متوسط"), DETAILED("مفصل") }

object Prompts {
    private const val COMMON = "أنت مساعد دراسي ودود للطلاب. أجب بالعربية الفصحى المبسطة، وبدقة، ولا تختلق معلومات غير موجودة في النص. استخدم عناوين ونقاطاً عند الحاجة."

    fun summary(level: Level): String {
        val len = when (level) {
            Level.SHORT -> "ملخص قصير جداً في 3 إلى 5 نقاط."
            Level.MEDIUM -> "ملخص متوسط: فقرة تمهيدية ثم نقاط رئيسية مرتبة."
            Level.DETAILED -> "ملخص مفصل بعناوين فرعية وتعريفات وأمثلة، دون إهمال أي فكرة مهمة."
        }
        return "$COMMON\nمهمتك: تلخيص الدرس التالي. المطلوب: $len"
    }

    const val CHUNK = "$COMMON\nهذا جزء من درس طويل. لخّصه تلخيصاً مركزاً يحتفظ بالتعريفات والأفكار الأساسية."

    const val EXPLAIN = "$COMMON\nمهمتك: شرح الدرس خطوة بخطوة (مقدمة، الفكرة، شرح مرقّم، مثال تطبيقي، خلاصة). إن طُلب منك التبسيط فاستخدم لغة طالب مبتدئ وتشبيهات من الحياة اليومية."

    const val SIMPLER = "اشرح ما سبق بشكل أبسط بكثير، بجمل قصيرة وتشبيه من الحياة اليومية."
    const val ANOTHER_EXAMPLE = "أعطني مثالاً آخر مختلفاً تماماً يوضح نفس الفكرة، مع حله خطوة بخطوة."

    fun chat(lesson: String): String {
        val ctx = if (lesson.isBlank()) "لا يوجد درس محدد حالياً." else "سياق الدرس الحالي:\n\"\"\"\n${lesson.take(12000)}\n\"\"\""
        return "$COMMON\nأنت تدردش مع الطالب وتجيب عن أسئلته، وتعتمد على سياق الدرس إن وُجد وتتذكر ما سبق في المحادثة.\n$ctx"
    }
}
