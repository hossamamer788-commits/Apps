package com.studentassistant.di

import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import com.studentassistant.BuildConfig
import com.studentassistant.data.remote.AiApi
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {
    @Provides @Singleton fun json() = Json { ignoreUnknownKeys = true }

    @Provides @Singleton fun client() = OkHttpClient.Builder()
        .readTimeout(120, TimeUnit.SECONDS) // مهم للـ Streaming
        .build()

    @Provides @Singleton fun api(client: OkHttpClient, json: Json): AiApi = Retrofit.Builder()
        .baseUrl(BuildConfig.BASE_URL).client(client)
        .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
        .build().create(AiApi::class.java)
}
