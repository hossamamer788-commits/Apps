package com.studentassistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Settings
import com.studentassistant.ui.settings.SettingsScreen
import androidx.compose.material3.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.studentassistant.ui.chat.ChatScreen
import com.studentassistant.ui.lesson.LessonScreen
import com.studentassistant.ui.theme.AppTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                val nav = rememberNavController()
                val route = nav.currentBackStackEntryAsState().value?.destination?.route
                Scaffold(bottomBar = {
                    NavigationBar {
                        NavigationBarItem(route == "lesson", { nav.navigate("lesson") { launchSingleTop = true } },
                            { Icon(Icons.Filled.MenuBook, null) }, label = { Text("الدرس") })
                        NavigationBarItem(route == "chat", { nav.navigate("chat") { launchSingleTop = true } },
                            { Icon(Icons.Filled.Chat, null) }, label = { Text("المحادثة") })
                        NavigationBarItem(route == "settings", { nav.navigate("settings") { launchSingleTop = true } },
                            { Icon(Icons.Filled.Settings, null) }, label = { Text("الإعدادات") })
                    }
                }) { pad ->
                    NavHost(nav, "lesson", Modifier.padding(pad)) {
                        composable("lesson") { LessonScreen() }
                        composable("chat") { ChatScreen() }
                        composable("settings") { SettingsScreen() }
                    }
                }
            }
        }
    }
}
