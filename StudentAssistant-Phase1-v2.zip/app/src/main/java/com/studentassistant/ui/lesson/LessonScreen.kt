package com.studentassistant.ui.lesson

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.studentassistant.domain.Level
import com.studentassistant.domain.Prompts
import com.studentassistant.ui.UiState
import com.studentassistant.ui.theme.DuoButton
import com.studentassistant.ui.theme.Orange
import com.studentassistant.ui.theme.OrangeDark

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LessonScreen(vm: LessonViewModel = hiltViewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val input by vm.input.collectAsStateWithLifecycle()
    val mode by vm.mode.collectAsStateWithLifecycle()
    val level by vm.level.collectAsStateWithLifecycle()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::loadPdf) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {

        Card(shape = RoundedCornerShape(20.dp)) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("🦉", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.width(12.dp))
                Text("أهلاً! الصق درسك أو ارفع ملف PDF وسأساعدك 💪", style = MaterialTheme.typography.titleMedium)
            }
        }

        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            Mode.entries.forEachIndexed { i, m ->
                SegmentedButton(mode == m, { vm.setMode(m) }, SegmentedButtonDefaults.itemShape(i, Mode.entries.size)) { Text(m.label) }
            }
        }

        if (mode == Mode.SUMMARY) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Level.entries.forEach { l -> FilterChip(level == l, { vm.setLevel(l) }, { Text(l.label) }) }
            }
        }

        OutlinedTextField(input, vm::onInput, Modifier.fillMaxWidth().heightIn(min = 160.dp, max = 260.dp),
            label = { Text("نص الدرس") }, shape = RoundedCornerShape(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            DuoButton("رفع PDF", { picker.launch(arrayOf("application/pdf")) }, Modifier.weight(1f), Orange, OrangeDark)
            DuoButton(if (mode == Mode.SUMMARY) "لخّص" else "اشرح", vm::run, Modifier.weight(1f),
                enabled = ui !is UiState.Loading)
        }

        when (val s = ui) {
            UiState.Idle -> {}
            UiState.Loading -> Box(Modifier.fillMaxWidth(), Alignment.Center) { CircularProgressIndicator() }
            is UiState.Error -> Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                Text(s.message, Modifier.padding(16.dp))
            }
            is UiState.Success -> {
                Card(shape = RoundedCornerShape(20.dp)) { Text(s.text, Modifier.padding(16.dp), style = MaterialTheme.typography.bodyLarge) }
                if (s.done) Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton({ vm.followUp(Prompts.SIMPLER) }, Modifier.weight(1f)) { Text("اشرحها أبسط") }
                    OutlinedButton({ vm.followUp(Prompts.ANOTHER_EXAMPLE) }, Modifier.weight(1f)) { Text("مثال آخر") }
                }
            }
        }
    }
}
