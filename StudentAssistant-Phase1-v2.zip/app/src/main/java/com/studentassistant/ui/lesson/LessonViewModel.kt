package com.studentassistant.ui.lesson

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.studentassistant.data.pdf.PdfTextExtractor
import com.studentassistant.data.remote.ChatMessageDto
import com.studentassistant.data.remote.ChatRequest
import com.studentassistant.domain.AiRepository
import com.studentassistant.domain.Level
import com.studentassistant.domain.LessonContext
import com.studentassistant.domain.Prompts
import com.studentassistant.ui.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class Mode(val label: String) { SUMMARY("تلخيص"), EXPLAIN("شرح") }

@HiltViewModel
class LessonViewModel @Inject constructor(
    private val repo: AiRepository,
    private val pdf: PdfTextExtractor,
    private val lessonCtx: LessonContext,
) : ViewModel() {

    val input = MutableStateFlow("")
    val mode = MutableStateFlow(Mode.SUMMARY)
    val level = MutableStateFlow(Level.MEDIUM)
    private val _ui = MutableStateFlow<UiState>(UiState.Idle)
    val ui = _ui.asStateFlow()

    private val convo = mutableListOf<ChatMessageDto>()
    private var system = ""
    private var job: Job? = null

    fun onInput(s: String) { input.value = s }
    fun setMode(m: Mode) { mode.value = m }
    fun setLevel(l: Level) { level.value = l }

    fun loadPdf(uri: Uri) {
        viewModelScope.launch {
            _ui.value = UiState.Loading
            runCatching { pdf.extract(uri) }
                .onSuccess { input.value = it; _ui.value = UiState.Idle }
                .onFailure { _ui.value = UiState.Error("تعذّر استخراج نص من الملف. قد يكون ممسوحاً ضوئياً (سندعمه لاحقاً بـ OCR).") }
        }
    }

    fun run() {
        val text = input.value.trim()
        if (text.isEmpty()) { _ui.value = UiState.Error("اكتب الدرس أو ارفع ملف PDF أولاً"); return }
        lessonCtx.text.value = text
        convo.clear()
        val isSummary = mode.value == Mode.SUMMARY
        system = if (isSummary) Prompts.summary(level.value) else Prompts.EXPLAIN
        launchStream(text, isSummary)
    }

    fun followUp(instruction: String) {
        if (_ui.value !is UiState.Success) return
        launchStream(instruction, chunkIfLong = false)
    }

    private fun launchStream(userText: String, chunkIfLong: Boolean) {
        job?.cancel()
        job = viewModelScope.launch {
            _ui.value = UiState.Loading
            try {
                var content = userText
                if (chunkIfLong && userText.length > CHUNK) {
                    // تقسيم النص الكبير ثم دمج الملخصات الجزئية
                    val partials = userText.chunked(CHUNK).map { part ->
                        async { repo.complete(ChatRequest("summary-chunk", Prompts.CHUNK, listOf(ChatMessageDto("user", part)))) }
                    }.awaitAll()
                    content = "ادمج هذه الملخصات الجزئية في ملخص واحد متسق:\n\n" + partials.joinToString("\n\n")
                }
                convo += ChatMessageDto("user", content)
                val sb = StringBuilder()
                repo.stream(ChatRequest(mode.value.name.lowercase(), system, convo.toList())).collect {
                    sb.append(it); _ui.value = UiState.Success(sb.toString(), false)
                }
                convo += ChatMessageDto("assistant", sb.toString())
                _ui.value = UiState.Success(sb.toString(), true)
            } catch (e: CancellationException) { throw e
            } catch (e: com.studentassistant.domain.MissingKeyException) {
                _ui.value = UiState.Error("أضف مفتاح API أولاً من تبويب الإعدادات ⚙️")
            } catch (e: Exception) {
                _ui.value = UiState.Error("حدث خطأ في الاتصال أو المفتاح/النموذج غير صحيح. راجع الإعدادات.")
            }
        }
    }

    companion object { private const val CHUNK = 8000 }
}
