package com.studentassistant.ui

sealed interface UiState {
    data object Idle : UiState
    data object Loading : UiState
    data class Success(val text: String, val done: Boolean) : UiState
    data class Error(val message: String) : UiState
}
