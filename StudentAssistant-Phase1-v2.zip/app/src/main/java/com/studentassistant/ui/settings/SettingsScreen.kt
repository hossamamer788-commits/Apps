package com.studentassistant.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import com.studentassistant.data.settings.Provider
import com.studentassistant.data.settings.SettingsStore
import com.studentassistant.ui.theme.DuoButton
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(val store: SettingsStore) : ViewModel()

@Composable
fun SettingsScreen(vm: SettingsViewModel = hiltViewModel()) {
    val s = vm.store
    var provider by remember { mutableStateOf(s.provider) }
    var key by remember(provider) { mutableStateOf(s.key(provider)) }
    var model by remember(provider) { mutableStateOf(s.model(provider)) }
    var saved by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("إعدادات الذكاء الاصطناعي", style = MaterialTheme.typography.headlineMedium)
        Text("المزوّد", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Provider.entries.forEach { p ->
                FilterChip(provider == p, { provider = p; saved = false }, { Text(p.label) })
            }
        }
        OutlinedTextField(key, { key = it; saved = false }, Modifier.fillMaxWidth(), label = { Text("مفتاح API") },
            singleLine = true, visualTransformation = PasswordVisualTransformation(), shape = RoundedCornerShape(16.dp))
        OutlinedTextField(model, { model = it; saved = false }, Modifier.fillMaxWidth(), label = { Text("اسم النموذج") },
            singleLine = true, shape = RoundedCornerShape(16.dp))
        DuoButton("حفظ", {
            s.provider = provider; s.setKey(provider, key); s.setModel(provider, model); saved = true
        })
        if (saved) Text("✅ تم الحفظ على جهازك")
        Text("المفتاح يُحفظ على هذا الجهاز فقط ولا يُرسل إلا إلى مزوّد الخدمة الذي اخترته.",
            style = MaterialTheme.typography.bodyMedium)
    }
}
