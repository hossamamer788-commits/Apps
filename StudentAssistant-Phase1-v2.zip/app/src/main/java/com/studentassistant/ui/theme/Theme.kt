package com.studentassistant.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

val Sky = Color(0xFF1CB0F6); val SkyDark = Color(0xFF1899D6)
val Orange = Color(0xFFFF9600); val OrangeDark = Color(0xFFD97E00)
val Purple = Color(0xFF8B5CF6)

private val Light = lightColorScheme(primary = Sky, secondary = Orange, tertiary = Purple,
    background = Color(0xFFF7FAFC), surface = Color.White)
private val Dark = darkColorScheme(primary = Sky, secondary = Orange, tertiary = Purple,
    background = Color(0xFF131F24), surface = Color(0xFF202F36))

// لإضافة خط Cairo/Tajawal: ضع ملفات ttf في res/font ثم اضبط fontFamily في Typography هنا
@Composable
fun AppTheme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(if (isSystemInDarkTheme()) Dark else Light, content = content)
    }
}

/** زر كبير مستدير بظل سفلي سميك على طريقة Duolingo */
@Composable
fun DuoButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier,
              color: Color = Sky, shadow: Color = SkyDark, enabled: Boolean = true) {
    Box(modifier.clip(RoundedCornerShape(16.dp)).background(if (enabled) shadow else Color.Gray)) {
        Button(onClick, Modifier.fillMaxWidth().padding(bottom = 4.dp).height(48.dp), enabled = enabled,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = color, disabledContainerColor = Color.LightGray)) {
            Text(text, style = MaterialTheme.typography.labelLarge)
        }
    }
}
