package com.studentassistant.ui.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.studentassistant.data.remote.ChatMessageDto
import com.studentassistant.data.remote.ChatRequest
import com.studentassistant.domain.AiRepository
import com.studentassistant.domain.LessonContext
import com.studentassistant.domain.Prompts
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class Msg(val role: String, val text: String, val error: Boolean = false)

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val repo: AiRepository,
    private val lessonCtx: LessonContext,
) : ViewModel() {

    private val _msgs = MutableStateFlow<List<Msg>>(emptyList())
    val msgs = _msgs.asStateFlow()
    private val _busy = MutableStateFlow(false)
    val busy = _busy.asStateFlow()
    val hasLesson get() = lessonCtx.text.value.isNotBlank()

    fun send(text: String) {
        if (text.isBlank() || _busy.value) return
        val history = _msgs.value.filter { !it.error }.map { ChatMessageDto(it.role, it.text) } + ChatMessageDto("user", text)
        _msgs.update { it + Msg("user", text) + Msg("assistant", "") }
        viewModelScope.launch {
            _busy.value = true
            val sb = StringBuilder()
            try {
                repo.stream(ChatRequest("chat", Prompts.chat(lessonCtx.text.value), history)).collect {
                    sb.append(it); setLast(Msg("assistant", sb.toString()))
                }
            } catch (e: com.studentassistant.domain.MissingKeyException) {
                setLast(Msg("assistant", "أضف مفتاح API أولاً من تبويب الإعدادات ⚙️", error = true))
            } catch (e: Exception) {
                setLast(Msg("assistant", "تعذّر الاتصال أو المفتاح/النموذج غير صحيح. راجع الإعدادات.", error = true))
            } finally { _busy.value = false }
        }
    }

    private fun setLast(m: Msg) = _msgs.update { it.dropLast(1) + m }
}
