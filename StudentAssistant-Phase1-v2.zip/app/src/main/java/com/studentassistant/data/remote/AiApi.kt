package com.studentassistant.data.remote

import okhttp3.ResponseBody
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Streaming
import retrofit2.http.Url

interface AiApi {
    /** واجهة متوافقة مع OpenAI (OpenRouter / NVIDIA) بصيغة SSE */
    @Streaming @POST
    suspend fun stream(@Url url: String, @Header("Authorization") auth: String, @Body req: OpenAiRequest): ResponseBody
}
