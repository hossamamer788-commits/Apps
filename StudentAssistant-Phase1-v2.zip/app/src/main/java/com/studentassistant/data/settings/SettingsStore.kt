package com.studentassistant.data.settings

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

enum class Provider(val label: String, val url: String, val defaultModel: String) {
    OPENROUTER("OpenRouter", "https://openrouter.ai/api/v1/chat/completions", "meta-llama/llama-3.3-70b-instruct:free"),
    NVIDIA("NVIDIA", "https://integrate.api.nvidia.com/v1/chat/completions", "meta/llama-3.1-70b-instruct"),
}

/** يحفظ المزوّد والمفتاح والنموذج على الجهاز فقط (SharedPreferences خاصة بالتطبيق) */
@Singleton
class SettingsStore @Inject constructor(@ApplicationContext ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var provider: Provider
        get() = runCatching { Provider.valueOf(sp.getString("provider", "")!!) }.getOrDefault(Provider.OPENROUTER)
        set(v) = sp.edit().putString("provider", v.name).apply()

    fun key(p: Provider) = sp.getString("key_${p.name}", "") ?: ""
    fun setKey(p: Provider, k: String) = sp.edit().putString("key_${p.name}", k.trim()).apply()

    fun model(p: Provider) = (sp.getString("model_${p.name}", "") ?: "").ifBlank { p.defaultModel }
    fun setModel(p: Provider, m: String) = sp.edit().putString("model_${p.name}", m.trim()).apply()
}
