package com.studentassistant.data.remote

import kotlinx.serialization.Serializable

@Serializable data class ChatMessageDto(val role: String, val content: String)
@Serializable data class ChatRequest(val feature: String, val system: String, val messages: List<ChatMessageDto>)
@Serializable data class OpenAiRequest(val model: String, val messages: List<ChatMessageDto>, val stream: Boolean = true)
