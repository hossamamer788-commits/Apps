package com.studentassistant.data.pdf

import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject

class PdfTextExtractor @Inject constructor(@ApplicationContext private val ctx: Context) {
    suspend fun extract(uri: Uri): String = withContext(Dispatchers.IO) {
        ctx.contentResolver.openInputStream(uri)!!.use { ins ->
            PDDocument.load(ins).use { PDFTextStripper().getText(it) }
        }.trim().also { require(it.isNotEmpty()) { "empty" } } // PDF ممسوح ضوئياً يحتاج OCR (مرحلة لاحقة)
    }
}
