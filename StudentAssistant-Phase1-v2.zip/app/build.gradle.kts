plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.hilt)
    alias(libs.plugins.ksp)
}
android {
    namespace = "com.studentassistant"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.studentassistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
        // Retrofit يحتاج baseUrl فقط، العناوين الفعلية في SettingsStore
        buildConfigField("String", "BASE_URL", "\"https://openrouter.ai/\"")
    }
    buildFeatures { compose = true; buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildTypes { release { isMinifyEnabled = true; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt")) } }
}
dependencies {
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui); implementation(libs.compose.material3)
    implementation(libs.compose.icons); implementation(libs.compose.preview)
    implementation(libs.activity.compose); implementation(libs.nav.compose)
    implementation(libs.lifecycle.vm); implementation(libs.lifecycle.rt)
    implementation(libs.hilt.android); ksp(libs.hilt.compiler); implementation(libs.hilt.nav)
    implementation(libs.retrofit); implementation(libs.retrofit.ser)
    implementation(libs.okhttp); implementation(libs.okhttp.log); implementation(libs.serialization)
    implementation(libs.pdfbox)
}
