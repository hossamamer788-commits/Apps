# مساعد الطالب الذكي — المرحلة 1

## بناء الـ APK
**أ) Android Studio:** افتح المجلد ← Sync ← Build > Build Bundle(s)/APK(s) > Build APK(s).
الملف في: app/build/outputs/apk/debug/app-debug.apk

**ب) GitHub (بدون تثبيت شيء):** ارفع المجلد كاملاً لمستودع جديد ← تبويب Actions ← Build APK ← Run workflow ← حمّل app-debug-apk من Artifacts.

## المفتاح
افتح تبويب «الإعدادات» داخل التطبيق، اختر OpenRouter أو NVIDIA، الصق المفتاح، واحفظ. (اسم النموذج قابل للتعديل.)
